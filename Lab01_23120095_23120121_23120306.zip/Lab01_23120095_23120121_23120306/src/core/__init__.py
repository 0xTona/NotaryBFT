# Core types and state
